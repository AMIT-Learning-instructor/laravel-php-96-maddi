<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="/test" method="post">
        <?php echo csrf_field(); ?>
    <button>send</button>
    </form>
</body>
</html><?php /**PATH /Users/youssefabbas/Desktop/Development/Work/AMIT LEARINIG/Full Stack Development/PHP 96 Maddi/Laravel/S2/blogs/resources/views/welcome.blade.php ENDPATH**/ ?>