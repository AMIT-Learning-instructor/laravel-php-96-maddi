<?php

use App\Http\Controllers\AuthorController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::get('authors',[AuthorController::class,'index']);
Route::get('authors/{author}',[AuthorController::class,'show']);
Route::put('authors/{author}',[AuthorController::class,'update']);
Route::delete('authors/{author}',[AuthorController::class,'destroy']);
Route::post('authors',[AuthorController::class,'store']);